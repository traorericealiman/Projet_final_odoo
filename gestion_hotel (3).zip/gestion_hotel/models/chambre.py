from odoo import models, fields, api
from odoo.exceptions import ValidationError

class HotelChambre(models.Model):
    _name = 'hotel.chambre'
    _description = 'Chambre d\'hôtel'

    name = fields.Char(string="Nom de la chambre", required=True)
    batiment_id = fields.Many2one('hotel.batiment', string="Bâtiment", required=True)
    type = fields.Selection([
        ('suite', 'Suite'),
        ('standard', 'Standard'),
        ('family', 'Family')
    ], string="Type de Chambre", required=True)
    prix = fields.Float(string="Prix", readonly=True)
    commodites_ids = fields.Many2many('hotel.commodite', string="Commodités")

    @api.model
    def create(self, vals):
        batiment = self.env['hotel.batiment'].browse(vals['batiment_id'])
        chambres_count = self.env['hotel.chambre'].search_count([('batiment_id', '=', batiment.id)])
        if chambres_count >= batiment.nbre:
            raise ValidationError("Le nombre de chambres ne peut pas dépasser le nombre de pièces.")
        
        prix_dict = {
            'suite': 300.0,
            'standard': 200.0,
            'family': 220.0
        }
        vals['prix'] = prix_dict.get(vals.get('type'), 0.0)
        
        return super(HotelChambre, self).create(vals)

    @api.onchange('type')
    def _onchange_type(self):
        prix_dict = {
            'suite': 300.0,
            'standard': 200.0,
            'deluxe': 250.0,
            'family': 220.0
        }
        self.prix = prix_dict.get(self.type, 0.0)
