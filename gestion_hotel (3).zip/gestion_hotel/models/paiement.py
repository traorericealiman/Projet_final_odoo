from odoo import models, fields, api

class HotelPayment(models.Model):
    _name = 'hotel.payment'
    _description = 'Hotel Payment'

    reservation_id = fields.Reference([
        ('hotel.reservation', 'Réservation Hôtel'),
        ('hotel.space.reservation', 'Réservation Espace')
    ], string='Réservation', required=True)
    payment_date = fields.Datetime(string='Date de paiement', default=fields.Datetime.now, required=True)
    payment_method = fields.Selection([
        ('cash', 'Cash'),
        ('credit_card', 'Credit Card'),
        ('bank_transfer', 'Bank Transfer')
    ], string='Méthode de paiement', required=True)
    prix_reservation = fields.Float(string='Prix de la réservation', compute='_compute_prix_reservation', store=True)

    @api.depends('reservation_id')
    def _compute_prix_reservation(self):
        for payment in self:
            if payment.reservation_id:
                if payment.reservation_id._name == 'hotel.reservation':
                    payment.prix_reservation = payment.reservation_id.prix_chambre
                elif payment.reservation_id._name == 'hotel.space.reservation':
                    space_reservation = payment.reservation_id
                    if space_reservation.space_id:
                        payment.prix_reservation = space_reservation.space_id.prix
                    else:
                        payment.prix_reservation = 0.0 
                else:
                    payment.prix_reservation = 0.0  
            else:
                payment.prix_reservation = 0.0
