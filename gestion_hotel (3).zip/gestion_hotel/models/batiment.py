from odoo import models, fields, api
from odoo.exceptions import ValidationError

class HotelBatiment(models.Model):
    _name = 'hotel.batiment'
    _description = "Bâtiment"

    name = fields.Char(string="Nom du bâtiment", required=True)
    nbre = fields.Integer(string="Nombre de pièces", required=True)

    @api.constrains('nbre')
    def _check_chambres_limit(self):
        for record in self:
            chambres_count = self.env['hotel.chambre'].search_count([('batiment_id', '=', record.id)])
            if chambres_count > record.nbre:
                raise ValidationError("Le nombre de chambres ne peut pas dépasser le nombre de pièces.")
