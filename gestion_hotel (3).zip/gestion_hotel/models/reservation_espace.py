from odoo import models, fields, api
from odoo.exceptions import ValidationError

class HotelSpaceReservation(models.Model):
    _name = 'hotel.space.reservation'
    _description = 'Réservation d\'Espace'

    client_id = fields.Many2one('hotel.client', string='Client', required=True)
    space_id = fields.Many2one('hotel.space', string='Espace', required=True)
    date_debut = fields.Date(string='Date de début', required=True)
    date_fin = fields.Date(string='Date de fin', required=True)
    prix_reservation = fields.Float(string='Prix de la réservation', compute='_compute_prix_reservation', store=True)

    @api.depends('space_id', 'date_debut', 'date_fin')
    def _compute_prix_reservation(self):
        for reservation in self:
            if reservation.space_id:

                reservation.prix_reservation = reservation.space_id.prix
            else:
                reservation.prix_reservation = 0.0

    @api.constrains('date_debut', 'date_fin', 'space_id')
    def _check_reservation_dates(self):
        for reservation in self:
            if reservation.date_debut >= reservation.date_fin:
                raise ValidationError('La date de début doit être avant la date de fin.')

            overlapping_reservations = self.env['hotel.space.reservation'].search([
                ('id', '!=', reservation.id),
                ('space_id', '=', reservation.space_id.id),
                ('date_debut', '<', reservation.date_fin),
                ('date_fin', '>', reservation.date_debut),
            ])
            if overlapping_reservations:
                raise ValidationError('Il est impossible de réserver cet espace aux dates et heures spécifiées car il y a déjà une réservation.')
