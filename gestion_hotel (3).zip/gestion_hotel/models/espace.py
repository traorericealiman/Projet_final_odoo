from odoo import models, fields, api

class HotelSpace(models.Model):
    _name = 'hotel.space'
    _description = 'Espace d\'hôtel'

    name = fields.Char(string='Nom', required=True)
    type = fields.Selection([
        ('salle_conference', 'Salle de conférence'),
        ('piscine', 'Piscine'),
        ('gym', 'Gym'),
        ('restaurant', 'Restaurant'),
        ('autre', 'Autre')
    ], string='Type', required=True)
    prix = fields.Float(string="Prix", readonly=True)
    reservation_ids = fields.One2many('hotel.space.reservation', 'space_id', string='Réservations')


    @api.model
    def create(self, vals):
        prix_dict = {
            'salle_conference': 500.0,
            'piscine': 300.0,
            'gym': 200.0,
            'restaurant': 400.0,
            'autre': 100.0
        }
        vals['prix'] = prix_dict.get(vals.get('type'), 0.0)
        return super(HotelSpace, self).create(vals)

    @api.onchange('type')
    def _onchange_type(self):
        prix_dict = {
            'salle_conference': 500.0,
            'piscine': 300.0,
            'gym': 200.0,
            'restaurant': 400.0,
            'autre': 100.0
        }
        self.prix = prix_dict.get(self.type, 0.0)