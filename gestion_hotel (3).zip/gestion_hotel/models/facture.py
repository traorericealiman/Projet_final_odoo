from odoo import models, fields, api

class HotelInvoice(models.Model):
    _name = 'hotel.invoice'
    _description = 'Facture'

    reservation_id = fields.Many2one('hotel.reservation', string='Réservation', required=True)
    client_id = fields.Many2one('hotel.client', string='Client', related='reservation_id.client_id', store=True)
    montant_total = fields.Float(string='Montant Total', compute='_compute_montant_total', store=True)

    @api.depends('reservation_id')
    def _compute_montant_total(self):
        for invoice in self:
            invoice.montant_total = invoice.reservation_id.prix_chambre  # Exemple de calcul du montant total, à adapter selon vos besoins

    # Méthode pour générer la facture
    def generate_invoice(self):
        Invoice = self.env['account.move']
        for invoice in self:
            invoice_vals = {
                'type': 'out_invoice',
                'partner_id': invoice.client_id.id,
                'invoice_line_ids': [(0, 0, {
                    'name': 'Chambre',
                    'quantity': 1,
                    'price_unit': invoice.montant_total,
                })],
            }
            new_invoice = Invoice.create(invoice_vals)
            invoice.reservation_id.invoice_id = new_invoice.id
