from odoo import models, fields

class HotelStaff(models.Model):
    _name = 'hotel.staff'
    _description = 'Personnel de l\'hôtel'

    name = fields.Char(string="Nom", required=True)
    job_title = fields.Selection([
        ('gardien', 'Gardien'),
        ('femme_menage', 'Femme de ménage'),
        ('receptionniste', 'Réceptionniste'),
        ('cuisinier', 'Cuisinier'),
        ('serveur', 'Serveur'),
    ],string="Titre du poste", required=True)
    phone = fields.Char(string="Téléphone")
    email = fields.Char(string="Email")
    hire_date = fields.Date(string="Date d'embauche")
    building_id = fields.Many2one('hotel.batiment', string="Bâtiment assigné")
