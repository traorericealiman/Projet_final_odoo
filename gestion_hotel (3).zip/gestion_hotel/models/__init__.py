# gestion_hotel/models/__init__.py
from . import batiment
from . import chambre
from . import commodite
from . import client
from . import reservation_chambre
from . import staff
from . import espace
from . import reservation_espace
from . import paiement

