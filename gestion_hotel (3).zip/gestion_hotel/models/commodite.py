from odoo import models, fields

class Commodite(models.Model):
    _name = 'hotel.commodite'
    _description = 'Commodité'

    name = fields.Char(string='Nom', required=True)
    description = fields.Text(string='Description')