from odoo import models, fields, api
from odoo.exceptions import ValidationError

class HotelReservation(models.Model):
    _name = 'hotel.reservation'
    _description = 'Réservation'

    client_id = fields.Many2one('hotel.client', string='Client', required=True)
    chambre_id = fields.Many2one('hotel.chambre', string='Chambre', required=True)
    date_debut = fields.Date(string='Date de début', required=True)
    date_fin = fields.Date(string='Date de fin', required=True)
    prix_chambre = fields.Float(string='Prix de la chambre', compute='_compute_prix_chambre', store=True)


    @api.depends('chambre_id')
    def _compute_prix_chambre(self):
        for reservation in self:
            if reservation.chambre_id:
                reservation.prix_chambre = reservation.chambre_id.prix
            else:
                reservation.prix_chambre = 0.0

    @api.constrains('chambre_id', 'date_debut', 'date_fin')
    def _check_chambre_disponibilite(self):
        for record in self:
            overlapping_reservations = self.search([
                ('chambre_id', '=', record.chambre_id.id),
                ('id', '!=', record.id),
                ('date_debut', '<=', record.date_fin),
                ('date_fin', '>=', record.date_debut),
            ])
            if overlapping_reservations:
                raise ValidationError('La chambre est déjà réservée pour les dates sélectionnées.')
    