# gestion_hotel/__manifest__.py
{
    'name': 'Gestion d\'Hôtel',
    'version': '1.0',
    'author': 'Traoré Aliman',
    'category': 'Gestion d\'Hôtel',
    'summary': 'Gérer les bâtiments, chambres, commodités, clients et réservations',
    'depends': ['base','hr','account'],
    'data': [
        'security/ir.model.access.csv',
        'views/batiment_views.xml',
        'views/chambre_views.xml',
        'views/commodite_views.xml',
        'views/client_views.xml',
        'views/staff_views.xml',
        'views/espace_views.xml',
        'views/reservation_espace_views.xml',
        'views/reservation_chambre_views.xml',
        'views/paiement_views.xml',
        # 'views/facture_views.xml',

    ],
    # 'images': ['static/description/icon.png'],
    'installable': True,
    'application': True,
}